
import React from 'react';

function Home() {
  return (
    <div>
      <h1>Welcome to Bug Bounty Learning App</h1>
      <p>Choose a challenge to get started!</p>
    </div>
  );
}

export default Home;
